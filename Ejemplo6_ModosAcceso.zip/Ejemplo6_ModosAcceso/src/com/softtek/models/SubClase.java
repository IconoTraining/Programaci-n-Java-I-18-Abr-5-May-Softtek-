package com.softtek.models;

public class SubClase extends MiClase{
	
	public void prueba() {
		metodoPublic();
		metodoProtected();
		metodoDefault();
	}

}
