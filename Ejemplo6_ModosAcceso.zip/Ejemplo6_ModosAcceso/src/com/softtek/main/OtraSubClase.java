package com.softtek.main;

import com.softtek.models.MiClase;

public class OtraSubClase extends MiClase{
	
	public void prueba() {
		metodoPublic();
		metodoProtected();
	}

}
