package com.softtek.main;

import com.softtek.models.MiClase;

public class AppMain {

	public static void main(String[] args) {
		
		MiClase miClase = new MiClase();
		
		miClase.metodoPublic();

	}

}
