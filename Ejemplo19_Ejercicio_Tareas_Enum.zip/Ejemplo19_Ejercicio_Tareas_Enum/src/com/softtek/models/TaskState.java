package com.softtek.models;

public enum TaskState {
	
	STARTED, PENDING, PERFORMED, COMPLETED;

}
