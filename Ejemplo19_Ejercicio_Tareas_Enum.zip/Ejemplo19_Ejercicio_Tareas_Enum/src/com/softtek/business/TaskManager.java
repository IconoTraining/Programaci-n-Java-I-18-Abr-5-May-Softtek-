package com.softtek.business;

import com.softtek.models.Task;
import com.softtek.models.TaskState;

public class TaskManager {
	
	public Task create(String creator) {
		Task task = new Task();
		task.setState(TaskState.STARTED);
		task.setCreator(creator);
		return task;
	}
	
	public void assign(Task task, String user) {
		if (task.getState() != TaskState.STARTED) {
			throw new RuntimeException("Task is not in STARTED state");
		}
		task.setState(TaskState.PENDING);
		task.setOwner(user);
	}
	
	public void perform(Task task) {
		if (task.getState() == TaskState.PENDING) {
			task.setState(TaskState.PERFORMED);
		} else {
			throw new RuntimeException("La tarea no esta en modo PENDING");
		}
	}
	
	public void review(Task task, boolean accept) {
		if (task.getState() == TaskState.PERFORMED) {
			if (accept) {
				task.setState(TaskState.COMPLETED);
			} else {
				task.setState(TaskState.PENDING);
			}
		} else {
			throw new RuntimeException("La tarea no esta en modo PERFORMED");
		}
	}

}
