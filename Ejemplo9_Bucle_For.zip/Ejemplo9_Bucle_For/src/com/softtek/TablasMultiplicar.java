package com.softtek;

public class TablasMultiplicar {

	public static void main(String[] args) {
		
		// bucle para recorrer las tablas
		for(int tabla = 1; tabla <= 10; tabla++) {
			System.out.println("****** Tabla del numero " + tabla + " ******");
		
			// bucle para recorrer los numeros
			for(int num=1; num <= 10; num++) {
				System.out.println(tabla + " x " + num + " = " + (tabla*num));
			}
			System.out.println();
		}

	}

}
