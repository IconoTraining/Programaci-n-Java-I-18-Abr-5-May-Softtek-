package com.softtek.main;

import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce edad: ");
		int edad = sc.nextInt();
		
		// Por defecto las aserciones estan deshabilitadas
		// Proyecto/ bton dcho/ run as../ run configurations.../Pestaña arguments/ VM options
		// ponemos -ea (Enabled Assertions)
		
		if (edad >= 18) {
			System.out.println("Eres mayor de edad");
		} else {
			assert (edad >= 0) : "La edad no puede ser negativa";
			System.out.println("Eres menor de edad");
		}

	}

}
