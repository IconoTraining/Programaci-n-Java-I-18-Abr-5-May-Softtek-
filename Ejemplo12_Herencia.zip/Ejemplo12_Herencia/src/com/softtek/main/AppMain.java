package com.softtek.main;

import com.softtek.models.Jefe;

public class AppMain {

	public static void main(String[] args) {
		
		Jefe jefe = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		System.out.println(jefe.getNombre());
		jefe.setSueldo(39000);
		
		
		System.out.println(jefe);
		
		// Cada vez que mostramos un objeto por consola internamente llama al toString()
		//System.out.println(jefe.toString());
		
		Jefe jefe1 = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		Jefe jefe2 = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		
		// Comprobar si los jefes son iguales
		// == solo funciona para tipos primitivos, compara el contenido de las variable
		System.out.println("Son iguales? " + (jefe1 == jefe2));
		
		// Los objetos se comparan con el metodo equals
		System.out.println("Son iguales? " + (jefe1.equals(jefe2)));

	}

}
