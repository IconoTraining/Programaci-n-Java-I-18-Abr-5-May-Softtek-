package com.softtek.main;

import com.softtek.models.Producto;

public class AppMain {

	// JVM invoca al metodo main de esta forma:
	// AppMain.main(.....)
	public static void main(String[] args) {
		
		Producto producto1 = new Producto(1, "Pantalla 17 pulgdas", 128.95);
		Producto producto2 = new Producto(2, "Teclado inalambrico", 49.50);
		
		System.out.println("Contador: " + producto2.getContador());
		
		// Es mas correcto llamar a los metodos estaticos a través de la clase
		System.out.println("Contador: " + Producto.getContador());
		
		// Ejemplos de metodos estaticos
		System.out.println("Potencia de 2 elevado a 8 " + Math.pow(2, 8));
		System.out.println("Cual es mayor, 5 ó 7? " + Integer.max(5, 7));
		System.out.println("Conversion de numero a texo " + String.valueOf(3));
		
		// Vamos a subir el precio de cada producto
		// Desde un contexto estatico solo se puede acceder a recursos estaticos:
		// 1ª forma de solucion: hacer estatico el metodo subirPrecio 
		// 2ª forma de solucion: crear una instancia de la clase AppMain()
		
		new AppMain().subirPrecio(producto1);
	
	}
	
	// Este metodo al no ser estatico necesita que se cree una instancia de la clase AppMain
	public  void subirPrecio(Producto producto) {
		// Incrementamos el 10% del precio
		producto.setPrecio(producto.getPrecio() * 1.1);
	}

}
