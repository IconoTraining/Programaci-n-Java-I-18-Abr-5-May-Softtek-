package com.softtek.models;

public class Cliente {
	
	// Propiedades, atributos, campos
	// Caracteristicas que necesito de un cliente
	
	// acceso tipo nombre = valor_inicial
	
	public String nombre;
	public String nif;
	public char sexo;
	public int edad;
	public boolean vip;
	public Direccion direccion;
	
	
	// Metodos, funciones, acciones
	
	// acceso tipo_retorno|void nombre(){}
	
	public void cambiarVip(boolean valor) {
		vip = valor;
	}
	
	public int verEdad() {
		return edad;
	}
	
	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Nif: " + nif + " Sexo: " + sexo 
				+ " Edad: " + edad + " Vip: " + vip + " Direccion: " + direccion.obtenerInfo() );
	}

}
