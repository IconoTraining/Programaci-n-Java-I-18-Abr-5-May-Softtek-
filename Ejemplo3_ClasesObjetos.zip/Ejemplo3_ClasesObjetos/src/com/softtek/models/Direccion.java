package com.softtek.models;

public class Direccion {
	
	public String calle;
	public int numero;
	public String poblacion;
	
	public String obtenerInfo() {
		return "C/ " + calle + ", " + numero + " (" + poblacion + ")";
	}

}
