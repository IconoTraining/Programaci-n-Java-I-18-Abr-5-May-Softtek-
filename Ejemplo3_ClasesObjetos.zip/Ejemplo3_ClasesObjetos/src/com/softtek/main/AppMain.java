package com.softtek.main;

//Toda clase que este en otro paquete necesitamos importarla
import com.softtek.models.Cliente;
import com.softtek.models.Direccion;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 67;
		String nombre = "Juan";
		
		// Crear el objeto de tipo Cliente o instanciar la clase Cliente
		Cliente cliente1 = new Cliente();
		
		// Asignar valores al objeto
		cliente1.nombre = "Juan";
		cliente1.nif = "12345678-A";
		cliente1.sexo = 'H';
		cliente1.edad = 48;
		cliente1.vip = true;
		cliente1.direccion = new Direccion();
		
		cliente1.direccion.calle = "Mayor";
		cliente1.direccion.numero = 57;
		cliente1.direccion.poblacion = "Madrid";
		
		// Acceder a los metodos
		cliente1.mostrarInfo();
		cliente1.cambiarVip(false);
		cliente1.mostrarInfo();
		
		// Crear otro objeto Cliente
		Cliente cliente2 = new Cliente();
		cliente2.nombre = "Maria";
		cliente2.nif = "98765432-B";
		cliente2.sexo = 'M';
		cliente2.edad = 35;
		cliente2.vip = false;
		
		// Primero creo el objeto Direccion
		Direccion direccion = new Direccion();
		direccion.calle = "Diagonal";
		direccion.numero = 82;
		direccion.poblacion = "Barcelona";
		
		// Asignamos la direccion como propiedad al cliente2
		cliente2.direccion = direccion;
		
		cliente2.mostrarInfo();
		cliente2.cambiarVip(true);
		cliente2.mostrarInfo();
		
		//syso + ctrl + space
		System.out.println(  cliente2.verEdad()  );
		

	}

}
