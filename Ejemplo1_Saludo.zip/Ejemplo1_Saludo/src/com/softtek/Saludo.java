// nombre de paquete en minusculas
package com.softtek;

// El nombre de la clase se empeza por mayuscula
public class Saludo {

	// Este metodo marca la clase como principal
	// sera la puerta de entrada a la aplicacion
	// main + ctrl + space
	public static void main(String[] args) {
		
		// Metodos y variables comienzan en minusculas
		
		// tipo nombreVariable = valor;
		String miNombre = "Anabel";
		
		// syso + ctrl + space
		System.out.println("Hola a todos, me llamo " + miNombre);
	}
}
