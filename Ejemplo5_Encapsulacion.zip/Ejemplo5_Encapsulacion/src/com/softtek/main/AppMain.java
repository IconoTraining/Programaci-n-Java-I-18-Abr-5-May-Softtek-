package com.softtek.main;

import com.softtek.models.Fecha;
import com.softtek.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		
		Fecha fecha = new Fecha();
		fecha.dia = 277880;
		fecha.mes = 778;
		fecha.anyo = -3;
		fecha.mostrar();
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(2088877);
		fechaEncapsulada.setMes(-4);
		fechaEncapsulada.setAnyo(90);
		fechaEncapsulada.mostrar();

	}

}
