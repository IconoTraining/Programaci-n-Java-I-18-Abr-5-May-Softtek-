package com.softtek.models;

public class FechaEncapsulada {

	// Los recursos privados solo se accede desde dentro de la clase
	private int dia;
	private int mes;
	private int anyo;

	// Metodo de lectura
	public int getDia() {
		return dia;
	}

	// Metodo de escritura
	public void setDia(int dia) {
		if (dia >=1 && dia <= 30) {
			this.dia = dia;
		} else {
			System.out.println("Dia no valido");
		}
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12) {
			this.mes = mes;
		} else {
			System.out.println("Mes no es valido");
		}
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo >= 2022 && anyo <= 2023) {
			this.anyo = anyo;
		} else {
			System.out.println("Año no valido");
		}
		
	}

	public void mostrar() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
