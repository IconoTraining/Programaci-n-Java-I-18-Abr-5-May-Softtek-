package com.softtek.main;


import com.softtek.models.Circulo;
import com.softtek.models.Figura;
import com.softtek.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo(10.50, 27.95, 40.32);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		Rectangulo rectangulo = new Rectangulo(10, 20, 30, 40);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		// No podemos crear objetos de una clase abstracta
		//Figura figura  = new Figura();
		
		// Si que me deja instanciarla si en el mismo momento implemento el metodo abstracto
		Figura triangulo = new Figura(2, 8) {
			
			private double base = 10;
			private double altura = 30;
			
			@Override
			public double calcularArea() {
				// TODO Auto-generated method stub
				return base * altura / 2;
			}
		};
		System.out.println("Area del triangulo: " + triangulo.calcularArea());

	}

}
