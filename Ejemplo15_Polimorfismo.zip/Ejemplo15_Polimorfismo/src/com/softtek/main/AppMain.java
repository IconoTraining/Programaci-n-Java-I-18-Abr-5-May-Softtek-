package com.softtek.main;

import com.softtek.models.Empleado;
import com.softtek.models.Jefe;
import com.softtek.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Aplicando polimorfismo
		Object object = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		Persona persona = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		Empleado empleado = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		Jefe jefe = new Jefe("Juan", 45, 'H', 38000, 15000, "1234-LVZ");
		
		// Que puedo ver? A que recursos tengo acceso?
		// Solo veo los recursos de tipo Object
		object.getClass();
		System.out.println("Instancia de Jefe? " + (object instanceof Jefe) );
		
		// Veo los recursos de Object y Persona
		persona.getClass();
		persona.getNombre();
		
		// Veo los recursos de Object, Persona y Empleado
		empleado.getClass();
		empleado.getNombre();
		empleado.getSueldo();
		
		// Tengo visibilidad total, veo los recursos de Object, Persona, Empleado y Jefe
		jefe.getClass();
		jefe.getNombre();
		jefe.getSueldo();
		jefe.getCoche();
		
		// Como podemos cambiar la visibilidad de un objeto??
		// El tipo de la variable es quien limita la visibilidad
		// SOLUCION: cambiar a otra variable de otro tipo
		Persona otraPersona = (Persona) object;
		Empleado otroEmpleado = (Empleado) object;
		
		// Esto tambien vale para cambiar la visibilidad
		((Jefe)object).getCoche();
		
		// Esto da un error -> ClassCastException
		Persona maria = new Persona("Maria", 27, 'M');
		Jefe jefaMaria = (Jefe)maria;

	}

}
