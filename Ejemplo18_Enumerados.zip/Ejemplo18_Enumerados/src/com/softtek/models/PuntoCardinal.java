package com.softtek.models;

public enum PuntoCardinal {

	NORTE('N', "North"), 
	SUR('S', "South"), 
	ESTE('E', "East"), 
	OESTE('O', "West");
	
	private char letra;
	private String nombreIngles;
	
	// El constructor de un tipo enumerado DEBE SER PRIVADO
	private PuntoCardinal(char letra, String ingles) {
		this.letra = letra;
		nombreIngles = ingles;
	}
	
	public char getLetra() {
		return letra;
	}
	
	public String getNombreIngles() {
		return nombreIngles;
	}
}
