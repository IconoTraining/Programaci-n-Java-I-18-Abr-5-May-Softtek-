package com.softtek.models;

public enum EstadoCivil {
	
	// Todos los valores se entienden como constantes: static y final
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;

}
