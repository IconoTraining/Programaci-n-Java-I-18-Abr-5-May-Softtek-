package com.softtek.main;

import com.softtek.business.Calculadora;
import com.softtek.util.DivisorException;

public class AppMain {

	public static void main(String[] args) {
		
		// Sumar todos los numeros recibidos como argumento
		int suma = 0;
		
		for (String dato: args) {
			int numero = 0;
			
			try {
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException e) {
				// Solo se ejecuta si se ha producido un error
				System.out.println("Se ha producido un error" + e.getMessage());
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				// Se ejecuta siempre, haya o no excepciones
				suma += numero;
			}
			
		}
		
		System.out.println("Suma: " + suma);
		
		
		
		// Instancia de Calculadora
		Calculadora calcu = new Calculadora();
		try {
			calcu.dividir(6, 2);
		} catch (DivisorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
