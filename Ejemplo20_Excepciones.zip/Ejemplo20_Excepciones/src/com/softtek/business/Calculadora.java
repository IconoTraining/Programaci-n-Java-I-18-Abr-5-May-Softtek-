package com.softtek.business;

import com.softtek.util.DivisorException;

public class Calculadora {
	
	// ......
	
	public double dividir(int dividendo, int divisor) throws DivisorException{
		
		double resultado = 0;
		
		if (divisor == 0) {
			throw new DivisorException("No se puede divir¡dir por 0");
		}
		
		return resultado;
	}

}
