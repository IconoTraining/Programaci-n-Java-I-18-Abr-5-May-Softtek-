package com.softtek.util;

public class DivisorException extends Exception{
	
	public DivisorException(String mensaje) {
		super(mensaje);
	}

}
