package com.softtek.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		// Set -> No permite duplicados, NO garantiza el orden de entrada
		// List -> Si permite duplicados, SI garantiza el orden de entrada
		
		Set conjunto = new HashSet();
		conjunto.add(4);
		conjunto.add(3.14);
		conjunto.add("Hola");
		conjunto.add(true);
		conjunto.add('A');
		conjunto.add("Hola");  // Los elementos repetidos los ignora
		
		System.out.println(conjunto);
		
		for (Object object : conjunto) {
			// cada elemento lo guarda como Object
		}
		
		// Otra forma de recorrer una coleccion
		for(Iterator it = conjunto.iterator(); it.hasNext(); ) {
			Object obj = it.next();
			System.out.println(obj);
		}
		
		List lista = new ArrayList();
		lista.add(4);
		lista.add(3.14);
		lista.add("Hola");
		lista.add(true);
		lista.add('A');
		lista.add("Hola");
		
		System.out.println(lista);
		
		// Metodos del api Collections
		// add -> agregar elemento a la coleccion
		
		// remove -> borrar elementos
		lista.remove(5);  // Borrar por posicion
		System.out.println(lista);
		
		lista.remove("Hola");  // Borrar por elemento
		System.out.println(lista);
		
		// size -> devuelve el numero de elementos de la coleccion
		System.out.println(lista.size());
		
		// isEmpty -> nos dice si la coleccion esta vacia
		System.out.println(lista.isEmpty());
		
		// contains -> nos dice si contieneun determinado elemento
		System.out.println(lista.contains('A'));
		
		// Recorrer la lista con un iterador
		Iterator it	= lista.listIterator();
		while (it.hasNext()) {
			Object object = (Object) it.next();
			System.out.println(object);
		}
		
		
		// Map; no se considera coleccion porque no hereda de Collections
		// los elementos se forman key-value
		// las claves (key) no se pueden repetir
		// pero los value si se pueden repetir
		// Tampoco se garantiza el orden de entrada
		Map mapa = new HashMap();
		mapa.put(1, "Hola");
		mapa.put(true, "Adios");
		mapa.put('A', "Anabel");
		mapa.put(true, "Hola");  // si repetimos clave, se sobreescribe
		
		System.out.println(mapa);
		
		// Recuperamos un elemento por si clave
		System.out.println(mapa.get(1));
		
		System.out.println(mapa.entrySet());
		System.out.println(mapa.keySet());
		System.out.println(mapa.values());
		
	}

}











