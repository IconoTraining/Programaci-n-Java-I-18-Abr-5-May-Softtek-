package com.softtek.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Genericos {

	public static void main(String[] args) {
		
		// El tipo generico siempre tiene que ser una clase,
		// no valen los tios primitivos
		// Son nuevos en la version 5
		//Set<String> nombres = new HashSet<String>();
		
		// A partir de Java 7 esto es redundante:
		Set<String> nombres = new HashSet<>();
		nombres.add("Juan");
		nombres.add("Pedro");
		nombres.add("Luis");
		nombres.add("Maria");
		nombres.add("Laura");
		//nombres.add(123);  // Error de compilacion
		
		System.out.println(nombres);
		

		List<Integer> numeros = new ArrayList<Integer>();
		numeros.add(40);
		numeros.add(5);
		numeros.add(28);
		numeros.add(16);
		numeros.add(9);
		
		System.out.println(numeros);
		
		
		Map<String, Double> notas = new HashMap<String, Double>();
		notas.put("Matematicas", 8.3);
		notas.put("Ingles", 6.9);
		notas.put("Fisica", 3.5);
		notas.put("Lengua", 9.7);
		
		System.out.println(notas);
		
		// Aprobar fisica
		notas.put("Fisica", 5.5);
		System.out.println(notas);
		
		// En que asignaturas estas matriculado
		System.out.println("Asignaturas: " + notas.keySet());
		
		// Mostrar la nota media
		int numAsignaturas = notas.size();
		double sumaNotas = 0;
		
		for(Double nota: notas.values()) {
			sumaNotas += nota;
		}
		
		System.out.println("Nota media: " + (sumaNotas / numAsignaturas) );
		
	}

}





