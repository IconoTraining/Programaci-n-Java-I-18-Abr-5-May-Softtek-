package com.softtek.main;

import com.softtek.models.Animal;
import com.softtek.models.Perro;
import com.softtek.models.ProductoVenta;

public class AppMain {

	public static void main(String[] args) {
		
		Perro perro = new Perro("Fifi", true, 2, 1234, 299.90, "Caniche", true);
		Animal animal = new Perro("Fifi", true, 2, 1234, 299.90, "Caniche", true);
		ProductoVenta pVenta = new Perro("Fifi", true, 2, 1234, 299.90, "Caniche", true);
		
		// Solo tengo acceso a los metodos de ProductoVenta y Object
		pVenta.getCodigo();
		
		// Solo tengo acceso a los metodos de Animal y Object
		animal.getNombre();
		
		System.out.println(perro);
		System.out.println(animal);
		System.out.println(pVenta);

	}

}
