package com.softtek.models;

public interface ProductoVenta {
	
	// Todas las propiedades declaradas en la interface so constantes
	
	// Los metodos de la interface son public y abstract
	int getCodigo();
	public void setCodigo(int codigo);
	
	abstract double getPrecio();
	public abstract void setPrecio(double precio);

}
