package com.softtek.main;

//Toda clase que este en otro paquete necesitamos importarla
import com.softtek.models.Cliente;
import com.softtek.models.Direccion;

public class AppMain {

	public static void main(String[] args) {
		
		
		// Crear el objeto de tipo Cliente o instanciar la clase Cliente
		Cliente cliente1 = new Cliente("Juan", "12345678-A", 'H', 48, 
				true, new Direccion("Mayor", 57, "Madrid"));
		
		
		// Acceder a los metodos
		cliente1.mostrarInfo();
		cliente1.cambiarVip(false);
		cliente1.mostrarInfo();
		
		// Crear otro objeto Cliente
		Cliente cliente2 = new Cliente("Maria", "98765432-B", 'M',  35, 
				false, new Direccion("Diagonal", 82, "Barcelona"));
		
		
		cliente2.mostrarInfo();
		cliente2.cambiarVip(true);
		cliente2.mostrarInfo();
		
		//syso + ctrl + space
		System.out.println(  cliente2.verEdad()  );
		

	}

}
