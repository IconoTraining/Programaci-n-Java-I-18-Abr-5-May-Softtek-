package com.softtek.models;

public class Cliente {

	// Propiedades, atributos, campos
	// Caracteristicas que necesito de un cliente

	// acceso tipo nombre = valor_inicial

	public String nombre;
	public String nif;
	public char sexo;
	public int edad;
	public boolean vip;
	public Direccion direccion;

	// Constructor
	public Cliente() {
		// TODO Auto-generated constructor stub
	}
	
	public Cliente(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}
	
	// Puedes tener tantos constructores como quieras pero han de ser diferentes entre si
	// se diferencian por numero de argumentos y por el tipo
//	public Cliente(String nif, int edad) {
//		super();
//		this.nif = nif;
//		this.edad = edad;
//	}

	public Cliente(String nombre, String nif, int edad) {
		super();
		this.nombre = nombre;
		this.nif = nif;
		this.edad = edad;
	}

	public Cliente(String nombre, String nif, char sexo, int edad, boolean vip, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.nif = nif;
		this.sexo = sexo;
		this.edad = edad;
		this.vip = vip;
		this.direccion = direccion;
	}

	// Metodos, funciones, acciones

	// acceso tipo_retorno|void nombre(){}

	public void cambiarVip(boolean valor) {
		vip = valor;
	}

	public int verEdad() {
		return edad;
	}

	public void mostrarInfo() {
		System.out.println("Nombre: " + nombre + " Nif: " + nif + " Sexo: " + sexo + " Edad: " + edad + " Vip: " + vip
				+ " Direccion: " + direccion.obtenerInfo());
	}

}
