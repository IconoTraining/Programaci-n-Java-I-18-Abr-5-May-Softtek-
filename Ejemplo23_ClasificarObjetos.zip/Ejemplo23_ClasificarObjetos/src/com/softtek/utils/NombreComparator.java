package com.softtek.utils;

import java.util.Comparator;

import com.softtek.models.Alumno;

public class NombreComparator implements Comparator<Alumno> {

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		return alum1.getNombre().compareTo(alum2.getNombre());
	}

}
