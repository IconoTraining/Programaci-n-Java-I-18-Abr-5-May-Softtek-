package com.softtek.utils;

import java.util.Comparator;

import com.softtek.models.Alumno;

public class NotaComparator implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		
		if (alum1.getNotaMedia() > alum2.getNotaMedia()) {
			return 1;
		} else if (alum1.getNotaMedia() < alum2.getNotaMedia()) {
			return -1;
		} else {
			return alum1.getApellido().compareTo(alum2.getApellido());
		}
	}

}
