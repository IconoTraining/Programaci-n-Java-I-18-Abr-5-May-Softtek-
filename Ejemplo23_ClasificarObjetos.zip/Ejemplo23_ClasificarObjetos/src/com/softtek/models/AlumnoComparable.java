package com.softtek.models;

public class AlumnoComparable implements Comparable<AlumnoComparable> {

	private int numMatricula;
	private String nombre;
	private String apellido;
	private double notaMedia;

	public AlumnoComparable() {
		// TODO Auto-generated constructor stub
	}

	public AlumnoComparable(int numMatricula, String nombre, String apellido, double notaMedia) {
		super();
		this.numMatricula = numMatricula;
		this.nombre = nombre;
		this.apellido = apellido;
		this.notaMedia = notaMedia;
	}

	@Override
	public int compareTo(AlumnoComparable otro) {
		// 1 o numero positivo si la instancia es mayor que el objeto recibido
		// -1 o numero negativo si la instancia es menor que el objeto recibido
		// 0 si son iguales
		
		if (notaMedia > otro.getNotaMedia()) {
			return 1;
		} else if (notaMedia < otro.getNotaMedia()) {
			return -1;
		} else {
			return nombre.compareTo(otro.getNombre());
		}
	}

	public int getNumMatricula() {
		return numMatricula;
	}

	public void setNumMatricula(int numMatricula) {
		this.numMatricula = numMatricula;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getNotaMedia() {
		return notaMedia;
	}

	public void setNotaMedia(double notaMedia) {
		this.notaMedia = notaMedia;
	}

	@Override
	public String toString() {
		return "AlumnoComparable [numMatricula=" + numMatricula + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", notaMedia=" + notaMedia + "]";
	}

}
