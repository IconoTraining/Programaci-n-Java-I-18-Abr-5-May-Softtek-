package com.softtek.models;

public class Alumno {

	private int numMatricula;
	private String nombre;
	private String apellido;
	private double notaMedia;

	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(int numMatricula, String nombre, String apellido, double notaMedia) {
		super();
		this.numMatricula = numMatricula;
		this.nombre = nombre;
		this.apellido = apellido;
		this.notaMedia = notaMedia;
	}

	public int getNumMatricula() {
		return numMatricula;
	}

	public void setNumMatricula(int numMatricula) {
		this.numMatricula = numMatricula;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getNotaMedia() {
		return notaMedia;
	}

	public void setNotaMedia(double notaMedia) {
		this.notaMedia = notaMedia;
	}

	@Override
	public String toString() {
		return "AlumnoComparable [numMatricula=" + numMatricula + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", notaMedia=" + notaMedia + "]";
	}

}
