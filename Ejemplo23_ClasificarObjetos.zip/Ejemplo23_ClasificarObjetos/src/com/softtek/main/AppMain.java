package com.softtek.main;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import com.softtek.models.Alumno;
import com.softtek.models.AlumnoComparable;
import com.softtek.utils.NombreComparator;
import com.softtek.utils.NotaComparator;

public class AppMain {

	public static void main(String[] args) {
		
		// Para tener los objetos clasificados se utilizan los arboles
		Set<AlumnoComparable> alumnosNota = new TreeSet<AlumnoComparable>();
		alumnosNota.add(new AlumnoComparable(1, "Juan", "Perez", 7.3));
		alumnosNota.add(new AlumnoComparable(5, "Pedro", "Arias", 4.8));
		alumnosNota.add(new AlumnoComparable(2, "Maria", "Rodriguez", 6.9));
		alumnosNota.add(new AlumnoComparable(6, "Luis", "Sanchez", 5.6));
		alumnosNota.add(new AlumnoComparable(3, "Laura", "Gomez", 7.3));
		alumnosNota.add(new AlumnoComparable(4, "Antonio", "Lara", 8.2));
		
		for (AlumnoComparable alumno : alumnosNota) {
			System.out.println(alumno);
		}
		System.out.println("--------------------------------");
		
		Comparator<Alumno> comparadorNota = new NotaComparator();
		Comparator<Alumno> comparadorNombre = new NombreComparator();
		
		Comparator<Alumno> comparadorNumMatricula = new Comparator<Alumno>() {
			
			@Override
			public int compare(Alumno alum1, Alumno alum2) {
				
				if (alum1.getNumMatricula() > alum2.getNumMatricula()) {
					return 1;
				} else if (alum1.getNumMatricula() < alum2.getNumMatricula()) {
					return -1;
				} else {
					return 0;
				}
			}
		};
		
		Comparator<Alumno> comparadorApellido = ((alum1, alum2) ->  {
			return alum1.getApellido().compareTo(alum2.getApellido());
		});
		
		//Set<Alumno> alumnos = new TreeSet<Alumno>(comparadorNombre);
		//Set<Alumno> alumnos = new TreeSet<Alumno>(comparadorNota);
		Set<Alumno> alumnos = new TreeSet<Alumno>(comparadorNumMatricula);
		alumnos.add(new Alumno(1, "Juan", "Perez", 7.3));
		alumnos.add(new Alumno(5, "Pedro", "Arias", 4.8));
		alumnos.add(new Alumno(2, "Maria", "Rodriguez", 6.9));
		alumnos.add(new Alumno(6, "Luis", "Sanchez", 5.6));
		alumnos.add(new Alumno(3, "Laura", "Gomez", 7.3));
		alumnos.add(new Alumno(4, "Antonio", "Lara", 8.2));
		
		for (Alumno alumno : alumnos) {
			System.out.println(alumno);
		}
		System.out.println("--------------------------------");

	}

}
