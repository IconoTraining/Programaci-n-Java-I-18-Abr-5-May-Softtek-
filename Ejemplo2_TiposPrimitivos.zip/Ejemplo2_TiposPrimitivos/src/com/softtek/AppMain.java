package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		// Tipos primitivos:
		
		/*
		 	1.- Numericos enteros:
		 		byte; 8 bits   01001100  -2 elevado a 7 hasta +2 elevado a 7 -1  -128 a 127
		 		short; 16 bits  -2 elevado a 15 hasta +2 elevado a 15 -1
		 		int;  32 bits (defecto)
		 		long;  64 bits. Hay que poner un sufijo l o L
		 */
		byte numByte = 100;
		short numShort = 10000;
		int numInt = 567987665;
		long numLong = 7765788878766584887L;
		
		
		/*
		 	2.- Numericos reales:
		 		float; 32 bits. Hay que poner como sufijo f o F
		 		double; 64 bits (defecto)
		 */
		float numFloat = 3.14F;
		double numDouble = 3.14;
		
		/*
		 	3.- Booleano
		 		boolean; solo admite true o false. Sin comillas
		 */
		boolean pagado = true;
		
		/*
		 	4.- Texto
		 		char; 16 bits. admite un solo caracter entre comillas 'simples'
		 */
		char sexo = 'M';
		char diaSemana = 'L';
		char euro = '€';
		
		// La clase String permite almacenar texto sin limite. Va entre comillas "dobles"
		// En Java las clases sirven de tipo de dato
		String nombre = "Pepito";
		String mensaje = "Hola, que tal?";
		
	}

}
