package com.softtek;

import java.util.Scanner;

public class AdivinaNumero {

	public static void main(String[] args) {
		
		// Generar un numero aleatorio de 1 a 10
		int numero = (int)( Math.random()* 10 + 1);
		//System.out.println(numero);
		
		// Se trata de adivinar el numero dando pistas
		Scanner sc = new Scanner(System.in);
		int prueba = 0;
		
		do {
			System.out.println("Introduce numero del 1 al 10: ");
			prueba = sc.nextInt();
			
			if (prueba > numero) {
				System.out.println("Te has pasado, prueba con un numero menor");
			} else if (prueba < numero) {
				System.out.println("Te has quedado corto, prueba con un numero mayor");
			}
			
		} while(prueba != numero);
		
		System.out.println("Enhorabuena, lo has adivinado");
		
		sc.close();
				
	}

}
