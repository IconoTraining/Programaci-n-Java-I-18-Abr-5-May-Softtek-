package com.softtek;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 8;
		
		// Convertir primitivo a objeto Integer
		// primitivo -> objeto (Boxing)
		Integer objInteger = Integer.valueOf(numero);
		Integer objInteger2 = new Integer(numero);
		
		// Convertir un objeto a tipo primitivo
		// objeto -> primitivo (Unboxing)
		numero = objInteger.intValue();
		
		// A partir de Java 5 podemos utilizar autoboxing
		Integer num = 6;
		int primitiva = objInteger;
		
		
		// Ejemplos de metodos de las clases envolventes
		System.out.println("Maximo entre 8 y 5: " + Integer.max(8, 5));
		System.out.println("H es una letra? : " + Character.isLetter('h'));
		System.out.println("H es un numero? : " + Character.isDigit('h'));
		System.out.println("182 en hexadecimal : " + Integer.toHexString(182));
		System.out.println("182 en octal : " + Integer.toOctalString(182));
		System.out.println("182 en binario : " + Integer.toBinaryString(182));
	}

}
