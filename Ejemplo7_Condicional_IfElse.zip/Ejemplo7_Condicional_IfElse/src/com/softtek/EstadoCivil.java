package com.softtek;

import java.util.Scanner;

public class EstadoCivil {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce estado civil (S,C,V,D,P): ");
		char estado = sc.next().charAt(0);
		
		if (estado == 'S' || estado == 's') {
			System.out.println("Soltero");
		} else if (estado == 'C' || estado == 'c') {
			System.out.println("Casado");
		} else if (estado == 'V' || estado == 'v') {
			System.out.println("Viudo");
		} else if (estado == 'D' || estado == 'd') {
			System.out.println("Divorciado");
		} else if (estado == 'P' || estado == 'p') {
			System.out.println("Pareja de Hecho");
		} else {
			System.out.println("Estado Civil desconocido");
		}

	}

}
