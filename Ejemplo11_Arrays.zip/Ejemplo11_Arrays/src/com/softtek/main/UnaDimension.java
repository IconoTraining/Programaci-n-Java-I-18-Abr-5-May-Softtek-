package com.softtek.main;

import java.util.Arrays;

import com.softtek.models.Cliente;
import com.softtek.models.Direccion;

public class UnaDimension {

	public static void main(String[] args) {
		
		// Declarar una variable de tipo array
		int numeros[];
		
		// Crear el array para 5 numeros
		numeros = new int[5];  // 5 es la longitud del array
		
		// Asignar valores al array
		numeros[0] = 6;
		numeros[1] = 3;
		numeros[2] = 9;
		numeros[3] = 7;
		numeros[4] = 4;  // indice esta entre 0 longitud-1
		
		// Todo en uno
		//int[] numeros2
		int [] numeros2 = {6,3,9,7,4};
		int [] numeros3 = new int[]{6,3,9,7,4};
		
		// Recorrer el array con el bucle for
		for(int i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		// Recorrer el array con bucle for-each
		for(int item  : numeros ) {
			System.out.println(item);
		}
		
		// Arrays de objetos
		Cliente clientes[] = new Cliente[3];
		clientes[0] = new Cliente("Pedro", "123456789-A", 'H', 50, false, new Direccion("Mayor", 56, "Madrid"));
		clientes[1] = new Cliente("Maria", "98765432-B", 'M', 45, true, new Direccion("Diagonal", 132, "Barcelona"));
		clientes[2] = new Cliente("Juan", "121212123-C", 'H', 38, false, new Direccion("Real", 12, "Sevilla"));
		
		// Todo en uno
		Cliente clientes2[] = {
				new Cliente("Pedro", "123456789-A", 'H', 50, false, new Direccion("Mayor", 56, "Madrid")),
				new Cliente("Maria", "98765432-B", 'M', 45, true, new Direccion("Diagonal", 132, "Barcelona")),
				new Cliente("Juan", "121212123-C", 'H', 38, false, new Direccion("Real", 12, "Sevilla"))
		};
		
		// Mostrar la edad de Juan
		System.out.println(clientes[2].edad);
		
		// Mostrar en que calle vive Pedro
		System.out.println(clientes[0].direccion.calle);
		
		
		// copiar arrays
		char letras[] = {'a','e','i','o','u'};
		char grande[] = new char[10];
		grande[0] = 'B';
		grande[1] = 'C';
		grande[2] = 'D';
		System.arraycopy(letras, 0, grande, 3, letras.length);
		System.out.println(grande);
		System.out.println(Arrays.toString(grande));

	}

}










