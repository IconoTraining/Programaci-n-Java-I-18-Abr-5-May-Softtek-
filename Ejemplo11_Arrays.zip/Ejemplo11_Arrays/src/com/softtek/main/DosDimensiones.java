package com.softtek.main;

import java.util.Arrays;

public class DosDimensiones {

	public static void main(String[] args) {
		
		// Declarar un array de 2 dimensiones
		int numeros[][];
		
		// Crear el array
		numeros = new int[3][2];  // 3 filas x 2 columnas
		
		// asignar valores array
		numeros[0][0] = 7;  // array[fila][columna]
		numeros[0][1] = 2;
		numeros[1][0] = 9;
		numeros[1][1] = 4;
		numeros[2][0] = 1;
		numeros[2][1] = 6; 
		
		// Todo en uno
		int numeros2[][] = { {7,2}, {9,4}, {1,6} };
		int numeros3[][] = new int[][]{ {7,2}, {9,4}, {1,6} };
		
		// Matrices no cuadradas
		int numeros4[][] = new int[3][];
		numeros4[0] = new int[2];
		numeros4[1] = new int[4];
		numeros4[2] = new int[3];
		
		// Asignar valores
		numeros4[0][0] = 6;
		numeros4[0][1] = 1;
		numeros4[1][0] = 9;
		numeros4[1][1] = 3;
		numeros4[1][2] = 8;
		numeros4[1][3] = 4;
		numeros4[2][0] = 0;
		numeros4[2][1] = 5;
		numeros4[2][2] = 7;
		
		int numeros5[][] = { {6,1}, {9,3,8,4}, {0,5,7} };
		
		// Recorrer una matriz (array de 2 dimensiones)
		for(int fila = 0; fila < numeros.length; fila++) {
			for (int columna = 0; columna < numeros[fila].length; columna++) {
				System.out.print(numeros[fila][columna] + "\t");
			}
			System.out.println();
		}
		
		// Recorrido con for-each
		for(int[] fila : numeros) {
			for(int num : fila) {
				System.out.print(num + "\t");
			}
			System.out.println();
		}
		
		// Crear una matriz de objetos
		String familias[][] = { 
				{"Luis", "Maria", "Jorge"}, 
				{"Pedro", "Esther", "Ana", "Lucas", "Jaime"}, 
				{"Antonio", "Raquel"}, 
				{"Manuel","Isabel", "Jorge", "Juan", "Carlos", "Marta"}
		};
		
		for (String[] familia: familias) {
			System.out.print("Padre: " + familia[0] + " ");
			System.out.print("Madre: " + familia[1] + " ");
			System.out.print("Hijos: ");
			
			for(int i = 2; i < familia.length; i++) {
				System.out.print(familia[i] + " ");
			}
			System.out.println();
		}
		
		System.out.println(Arrays.deepToString(familias));

	}

}






