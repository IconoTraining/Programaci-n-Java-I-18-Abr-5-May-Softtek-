package com.softtek.models;

public class Direccion {
	
	// propiedades
	public String calle;
	public int numero;
	public String poblacion;
	
	// constructores
	
	// Si la clase ya tiene un constructor, el compilador no añade el constructor por defecto
	// En este caso lo agregamos nosotros
	public Direccion() {
	}
	
	public Direccion(String calle, int numero, String poblacion) {
		super();
		this.calle = calle;
		this.numero = numero;
		this.poblacion = poblacion;
	}
	
	// metodos
	public String obtenerInfo() {
		return "C/ " + calle + ", " + numero + " (" + poblacion + ")";
	}

	

}
