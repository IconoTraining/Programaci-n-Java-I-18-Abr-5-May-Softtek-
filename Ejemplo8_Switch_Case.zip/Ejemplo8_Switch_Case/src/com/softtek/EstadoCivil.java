package com.softtek;

import java.util.Scanner;

public class EstadoCivil {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce estado civil (S,C,V,D,P): ");
		char estado = sc.next().charAt(0);
		
		switch (estado) {
		case 'S':
		case 's':
			System.out.println("Soltero");
			break;

		case 'C':
		case 'c':
			System.out.println("Casado");
			break;

		case 'V':
		case 'v':
			System.out.println("Viudo");
			break;

		case 'D':
		case 'd':
			System.out.println("Divorciado");
			break;

		case 'P':
		case 'p':
			System.out.println("Pareja de hecho");
			break;

		default:
			System.out.println("Estado civil desconocido");
			break;
		}

	}

}
